import javax.swing.*;

public class LookAndFeel{
	
  public static void main(String[] args){

    new MainFrame();
  } // end of main
}//end of class LookAndFeel