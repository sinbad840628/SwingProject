import javax.swing.*;

public class LookAndFeel{
	
  public static void main(String[] args){

    JFrame F = new MainFrame();
    F.setVisible(true); 
  } // end of main
}//end of class LookAndFeel